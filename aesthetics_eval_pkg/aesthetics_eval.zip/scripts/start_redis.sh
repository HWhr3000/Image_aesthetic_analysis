#!/usr/bin/env bash
set -euo pipefail
redis-server --port 6379
